export type Images = {
  id: number;
  image: string;
};
