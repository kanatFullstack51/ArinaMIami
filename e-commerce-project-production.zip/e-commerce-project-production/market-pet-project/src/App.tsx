import { useState } from "react";
import Layout from "./pages/Layout/Layout";

function App() {
  return (
    <div>
      <Layout />
    </div>
  );
}

export default App;
